﻿namespace Extensibility
{
    public interface ILogger
    {
        void LogError(string msg);
            void LogInfo(string msg);
    }
}
