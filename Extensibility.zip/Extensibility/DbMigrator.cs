﻿using System;

namespace Extensibility
{
    public class DbMigrator 
    {
        private readonly ILogger logger;

        public DbMigrator(ILogger logger)
        {
            this.logger = logger;
        }
        public void Migrator()
        {
            logger.LogInfo("Migrating Start at {0} " + DateTime.Now);
            logger.LogInfo("Migrating Finished at {0} " + DateTime.Now);
        }
    }
}
